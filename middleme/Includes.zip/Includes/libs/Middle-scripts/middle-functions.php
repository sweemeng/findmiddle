<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

// General libraries for updating tabel
// also to get and answer to json calls ...

function add_new_appointment($from_email, $from_lat, $from_lng, $to_email)
{
    $sql = "INSERT INTO appointment (lat,lng) VALUES (0,0)";
    $res = mysql_query($sql);
    if (!$res)
    {
        echo "Died! SQL is $sql" . mysql_error();
        return false;
    }
    else
    {
        $appointment_id = mysql_insert_id();
        $is_originator = 1;
        $res = insert_new_participant($appointment_id, $from_email, $from_lat, $from_lng, $is_originator);
        if (! $res)
        {
            echo "insert_new_participant ORIGINATOR FAILED!";
            return false;
        }

        $is_originator = 0;
        $res = insert_new_participant($appointment_id, $to_email, 0, 0, $is_originator);
        if (! $res)
        {
            echo "insert_new_participant NON-ORIGINATOR FAILED!";
            return false;
        }
    }

    return $appointment_id;
}

function insert_new_participant($appointment_id, $email, $lat, $lng, $is_originator)
{
    // Create entry for sender and link
    $sql = "INSERT INTO participant
                (email, lat, lng, originator, appointment_id)
                VALUES
                ('$email', $lat, $lng, $is_originator, $appointment_id)";
    $res = mysql_query($sql);
    if (!$res)
    {
        echo "Died! SQL is $sql" . mysql_error();
        return false;
    }

    return true;
}

function update_non_originator_participant($appointment_id, $to_lat, $to_lng)
{
    $sql = "UPDATE participant SET lat = $to_lat, lng = $to_lng WHERE appointment_id = $appointment_id";
    $res = mysql_query($sql);

    if (! $res)
    {
        echo "SQL is $sql! ERR: " . mysql_error();
        return false;
    }

    return true;
}

function get_originator_email($appointment_id)
{
    if (empty($appointment_id))
    {
        echo "Appointment ID not defined!";
        return false;
    }
    $sql = "SELECT email FROM participant WHERE appointment_id = $appointment_id AND originator = 1";
    $res = mysql_query($sql);
    if (! $res)
    {
        echo "SQL is $sql. ERR: " . mysql_error();
        return false;
    }
    return mysql_result($res, 0, "email");
}

function get_non_originator_email($appointment_id)
{
    if (empty($appointment_id))
    {
        echo "Appointment ID not defined!";
        return false;
    }
    $sql = "SELECT email FROM participant WHERE appointment_id = $appointment_id AND originator = 0";
    $res = mysql_query($sql);
    if (! $res)
    {
        echo "SQL is $sql. ERR: " . mysql_error();
        return false;
    }

    return mysql_result($res, 0, "email");
}

?>
